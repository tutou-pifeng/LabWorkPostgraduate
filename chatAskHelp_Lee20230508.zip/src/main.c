/*
 * Copyright (c) 2019 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

/** @file
 *  @brief Nordic Mesh light sample
 */
#include <zephyr/bluetooth/bluetooth.h>
#include <bluetooth/mesh/models.h>
#include <bluetooth/mesh/dk_prov.h>
#include <dk_buttons_and_leds.h>
#include "model_handler.h"

#include <zephyr/logging/log.h>

#include <stdio.h>
#include <string.h>
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/ring_buffer.h>

#include <zephyr/usb/usb_device.h>



LOG_MODULE_REGISTER(chat, CONFIG_LOG_DEFAULT_LEVEL);

BUILD_ASSERT(DT_NODE_HAS_COMPAT(DT_CHOSEN(zephyr_console), zephyr_cdc_acm_uart),
	     "Console device is not ACM CDC UART device");

#define RING_BUF_SIZE 1024
uint8_t ring_buffer[RING_BUF_SIZE];
struct ring_buf ringbuf;
/*--------------------*/
static int DK2PhoneFlagLee = 0;
#define MY_STACK_SIZE 512
struct k_thread Dk2PhoneThreadLee;
K_THREAD_STACK_DEFINE(stackLee, MY_STACK_SIZE);

char strLee[] = "11111";
char *pstrLee = strLee;
uint16_t meshAddressLee = 0x0001;

void DevelopBoard2PhoneThreadFunc(void *p1, void *p2, void *p3)
{
	//printk("ThreadOK_Lee\n");
	//char strLee[] = "11111";
	DevelopBoard2Phone(meshAddressLee, pstrLee);
}

/*--------------------*/



//Lee:Send a string using putty, where the interrupt will enter multiple times. Interrupt enters three times, while loop enters two times；
static void interrupt_handler(const struct device *dev, void *user_data)
{
	ARG_UNUSED(user_data);

	while (uart_irq_update(dev) && uart_irq_is_pending(dev)) {

		if (uart_irq_rx_ready(dev)) {
			int recv_len, rb_len;
			uint8_t buffer[64];
			size_t len = MIN(ring_buf_space_get(&ringbuf),
					 sizeof(buffer));

			recv_len = uart_fifo_read(dev, buffer, len);
			if (recv_len < 0) {
				LOG_ERR("Failed to read UART FIFO");
				recv_len = 0;
			};

			rb_len = ring_buf_put(&ringbuf, buffer, recv_len);
			if (rb_len < recv_len) {
				LOG_ERR("Drop %u bytes", recv_len - rb_len);
			}

			LOG_DBG("tty fifo -> ringbuf %d bytes", rb_len);
			if (rb_len) {
				uart_irq_tx_enable(dev);
			}
		}

		
		if (uart_irq_tx_ready(dev)) {
			uint8_t buffer[64];
			int rb_len;

			rb_len = ring_buf_get(&ringbuf, buffer, sizeof(buffer));
			if (!rb_len) {
				LOG_DBG("Ring buffer empty, disable TX IRQ");
				uart_irq_tx_disable(dev);
				continue;
			}

			int i;
			char strRaw[100] = "1";
			for(i=0;i<rb_len;i++)
			{
				strRaw[i] = buffer[i];
			}
			strRaw[i] = '\0';   
			
			printk("Hello World! %s\n", strRaw);
		

		}
	}

	DK2PhoneFlagLee++;
	if(DK2PhoneFlagLee == 3)
	{
		k_tid_t my_tid = k_thread_create(&Dk2PhoneThreadLee, stackLee, sizeof(stackLee), DevelopBoard2PhoneThreadFunc,
			NULL, NULL, NULL, 5, 0,
			K_NO_WAIT);
		k_thread_start(my_tid);

		DK2PhoneFlagLee = 0;
	}

}


static void bt_ready(int err)
{
	if (err) {
		printk("Bluetooth init failed (err %d)\n", err);
		return;
	}

	printk("Bluetooth initialized\n");

	dk_leds_init();
	dk_buttons_init(NULL);

	err = bt_mesh_init(bt_mesh_dk_prov_init(), model_handler_init());
	if (err) {
		printk("Initializing mesh failed (err %d)\n", err);
		return;
	}

	if (IS_ENABLED(CONFIG_SETTINGS)) {
		settings_load();
	}

	/* This will be a no-op if settings_load() loaded provisioning info */
	bt_mesh_prov_enable(BT_MESH_PROV_ADV | BT_MESH_PROV_GATT);

	printk("Mesh initialized\n");
}

void main(void)
{
	int err;

	const struct device *const dev = DEVICE_DT_GET(DT_CHOSEN(zephyr_console));
	uint32_t dtr = 0;

	printk("Initializing...\n");

	err = bt_enable(bt_ready);
	if (err) {
		printk("Bluetooth init failed (err %d)\n", err);
	}

	if (usb_enable(NULL)) {
		return;
	}

	for(int i = 1;i<40;i++) {
		printk("Hello World! %s\n", CONFIG_ARCH);
		//k_sleep(K_SECONDS(1));
	}

	ring_buf_init(&ringbuf, sizeof(ring_buffer), ring_buffer);
	while (true) {
		uart_line_ctrl_get(dev, UART_LINE_CTRL_DTR, &dtr);
		if (dtr) {
			break;
		} else {
			/* Give CPU resources to low priority threads. */
			k_sleep(K_MSEC(100));
		}
	}

	uart_irq_callback_set(dev, interrupt_handler);

	/* Enable rx interrupts */
	uart_irq_rx_enable(dev);

}
